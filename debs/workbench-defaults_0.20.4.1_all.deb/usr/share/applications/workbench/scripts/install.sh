#/bin/bash
sudo apt-get -y install clonezilla partclone fsarchiver nwipe freefilesync grsync gftp-gtk blockout2 attr rename mx-boot-options \
geany ceni wireshark zenmap chntpw nmap meld memtester fping screen iputils-arping iputils-ping iputils-tracepath ncdu \
dvtm telnet rkhunter chkrootkit dtrx clamav clamtk dcfldd w3m lynx vim ghex wakeonlan iperf dmraid fio bonnie++ \
stressapptest abiword linssid gvfs-backends light-locker iotop iftop





